# radiodj
RadioDJ php web for http://www.radiodj.ro

Simple RadioDJ php web

INSTALLATION

1. Place the Plugin_Requests.dll file in the plugin folder within RadioDJ. (This file can be found in the disabled plugins folder)

2. Open “inc/config.php” and enter your Database and MySQL server details;

3. Upload all the files to your web server;

4. If the webserver is not on the same computer with the MySQL database, you will need to create a new MySQL user that can connect from your webserver to your MySQL server. Also it is important that the firewall ports used for for MySQL to be open on both your webserver and your computer (and routers if any).



Screenshots:
![alt tag](http://i.imgur.com/CXLYRyL.png)
![alt tag](http://i.imgur.com/JQzwhgt.png)
![alt tag](http://i.imgur.com/T1sLp4J.png)
